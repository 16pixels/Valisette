(window.webpackJsonp=window.webpackJsonp||[]).push([[1],{U9Q4:
/*!***********************************************************************!*\
  !*** ./resources/assets/javascript/vue-app/i18n/languages/lang-fr.js ***!
  \***********************************************************************/
/*! exports provided: default */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is referenced from these modules with unsupported syntax: ./resources/assets/javascript/vue-app/i18n/languages lazy ^\.\/lang\-.*$ namespace object (referenced with context element) */function(o,e,n){"use strict";n.r(e),e.default={message:{hello:"Bonjour Monde"}}}}]);