(window.webpackJsonp=window.webpackJsonp||[]).push([[1],{"r+y8":
/*!***********************************************************************!*\
  !*** ./resources/assets/javascript/vue-app/i18n/languages/lang-en.js ***!
  \***********************************************************************/
/*! exports provided: default */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is referenced from these modules with unsupported syntax: ./resources/assets/javascript/vue-app/i18n/languages lazy ^\.\/lang\-.*$ namespace object (referenced with context element) */function(e,o,s){"use strict";s.r(o),o.default={message:{hello:"Hello World"}}}}]);