(window.webpackJsonp=window.webpackJsonp||[]).push([[0],{"./resources/assets/javascript/vue-app/i18n/languages/lang-fr.js":
/*!***********************************************************************!*\
  !*** ./resources/assets/javascript/vue-app/i18n/languages/lang-fr.js ***!
  \***********************************************************************/
/*! exports provided: default */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is referenced from these modules with unsupported syntax: ./resources/assets/javascript/vue-app/i18n/languages lazy ^\.\/lang\-.*$ namespace object (referenced with context element) */function(s,e,a){"use strict";a.r(e),e.default={message:{hello:"Bonjour Monde"}}}}]);